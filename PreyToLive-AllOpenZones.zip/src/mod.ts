import { DependencyContainer } from "tsyringe";
import { IPostDBLoadMod } from "@spt-aki/models/external/IPostDBLoadMod";
import { DatabaseServer } from "@spt-aki/servers/DatabaseServer";
import { ILogger } from "@spt-aki/models/spt/utils/ILogger";
import { LogTextColor } from "@spt-aki/models/spt/logging/LogTextColor";

import pkg from "../package.json";
import config from "../config/config.json";

class AllOpenZones implements IPostDBLoadMod
{
    public postDBLoad(container: DependencyContainer): void
    {
        const logger: ILogger = container.resolve<ILogger>("WinstonLogger");
        const pkgName = `${pkg.author}-${pkg.name}`;

        logger.info(`Loading: ${pkgName} ${pkg.version}${config.allOpenZones.enabled === true ? "" : " [Disabled]"}`);

        const locations = container.resolve<DatabaseServer>("DatabaseServer").getTables().locations;
        const maps = {
            "bigmap": "ZoneBlockPost,ZoneBlockPostSniper,ZoneBlockPostSniper3,ZoneBrige,ZoneCrossRoad,ZoneCustoms,ZoneDormitory,ZoneFactoryCenter,ZoneFactorySide,ZoneGasStation,ZoneOldAZS,ZoneScavBase,ZoneSnipeBrige,ZoneSnipeFactory,ZoneSnipeTower,ZoneTankSquare,ZoneWade",
            "laboratory": "BotZoneBasement,BotZoneFloor1,BotZoneFloor2,BotZoneGate1,BotZoneGate2",
            "lighthouse": "Zone_Blockpost,Zone_Bridge,Zone_Chalet,Zone_Containers,Zone_DestroyedHouse,Zone_Hellicopter,Zone_LongRoad,Zone_OldHouse,Zone_Rocks,Zone_RoofBeach,Zone_RoofContainers,Zone_RoofRocks,Zone_SniperPeak,Zone_TreatmentBeach,Zone_TreatmentContainers,Zone_TreatmentRocks,Zone_Village",
            "rezervbase": "ZoneBarrack,ZoneBunkerStorage,ZonePTOR1,ZonePTOR2,ZoneRailStrorage,ZoneSubCommand,ZoneSubStorage",
            "shoreline": "ZoneBunker,ZoneBunkeSniper,ZoneBusStation,ZoneForestGasStation,ZoneForestSpawn,ZoneForestTruck,ZoneGasStation,ZoneGreenHouses,ZoneIsland,ZoneMeteoStation,ZonePassClose,ZonePassFar,ZonePort,ZonePowerStation,ZonePowerStationSniper,ZoneRailWays,ZoneSanatorium1,ZoneSanatorium2,ZoneTunnel,ZoneStartVillage",
            "woods": "ZoneBigRocks,ZoneBrokenVill,ZoneClearVill,ZoneHighRocks,ZoneHouse,ZoneMiniHouse,ZoneRedHouse,ZoneRoad,ZoneScavBase2,ZoneWoodCutter"
        }

        const enabled: boolean = config.allOpenZones.enabled;

        if (typeof enabled === "boolean")
        {
            if (enabled)
            {
                for (const map in maps)
                {
                    locations[map].base.OpenZones = maps[map];
                }
                return;
            }
            else
            {
                return;
            }
        }
        else
        {
            logger.log("AllOpenZones[enabled] is incorrect, it must be set to true to enable it or false to disable it.", LogTextColor.red);
            return;
        }
    }
}

module.exports = { mod: new AllOpenZones() };