export declare class Program {
    constructor();
    start(): void;
}
