export declare const TYPES: {
    [name: string]: symbol;
};
