export interface ILocationsBase {
    locations: Locations;
    paths: Path[];
}
export interface Locations {
}
export interface Path {
    Source: string;
    Destination: string;
}
