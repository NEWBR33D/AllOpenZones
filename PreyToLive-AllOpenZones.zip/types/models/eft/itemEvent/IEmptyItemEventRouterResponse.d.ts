import { IItemEventRouterBase } from "./IItemEventRouterBase";
export interface IEmptyItemEventRouterResponse extends IItemEventRouterBase {
    profileChanges: "";
}
