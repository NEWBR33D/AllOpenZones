import { ILoginRequestData } from "./ILoginRequestData";
export declare type IRemoveProfileData = ILoginRequestData;
