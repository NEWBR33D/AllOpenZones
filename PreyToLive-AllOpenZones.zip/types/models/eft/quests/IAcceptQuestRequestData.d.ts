export interface IAcceptQuestRequestData {
    Action: "QuestAccept";
    qid: string;
    type: string;
}
