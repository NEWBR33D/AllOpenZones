export declare enum BotAmount {
    AsOnline = "AsOnline",
    Low = "Low",
    Medium = "Medium",
    High = "High",
    Horde = "Horde"
}
