import { Preset } from "../../eft/common/IGlobals";
export interface CustomPreset {
    key: string;
    preset: Preset;
}
